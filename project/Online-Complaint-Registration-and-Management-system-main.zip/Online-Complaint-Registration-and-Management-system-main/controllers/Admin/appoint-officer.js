exports.appoint_officer=(req,res)=>{
    res.sendFile(__dirname+"/appoint-officer.html")
}